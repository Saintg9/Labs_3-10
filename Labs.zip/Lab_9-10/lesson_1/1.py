
from jinja2 import Template
import os.path
import json

# -


def get_file_content(path):
    if os.path.isfile(path):
        with open(path, "r", encoding='utf-8') as txt_infile:
            file_content = txt_infile.read()
    else:
        print("File not exists")

    return file_content


# -

def get_final_msg(json_answers_path, msg_template):

    if os.path.isfile(json_answers_path):
        with open('answers.json', "r", encoding='utf-8') as json_infile:
            answers = json.load(json_infile)
            for answer in answers['data']:
                user_name = answer["Имя"]
                time = answer["Срок"]
                item = answer["Предмет"]
                place = answer["Место"]
    else:
        user_name = input("Имя: ")
        time = input("Срок: ")
        item = input("Предмет: ")
        place = input("Место: ")

    return msg_template.render(u_n=user_name, t=time, i=item, p=place)


# -
if __name__ == "__main__":

    tm = Template(get_file_content('lesson_1/template.txt'))

    print(get_final_msg('answers.json', tm))
